﻿using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class SimpleCollectibleScript : MonoBehaviour
{
    [Header("Basic Settings")]
    public bool rotate = true;
    public float rotationSpeed = 60f;
    public AudioClip collectSound;
    public GameObject collectEffect;

    [Header("Debug")]
    public bool showDebugLogs = true;

    private AudioSource audioSource;

    void Start()
    {
        // 初始化组件
        audioSource = GetComponent<AudioSource>();
        audioSource.playOnAwake = false;

        // 自动设置标签（如果未设置）
        if (string.IsNullOrEmpty(gameObject.tag) || !gameObject.CompareTag("Collectible"))
        {
            gameObject.tag = "Collectible";
            if (showDebugLogs) Debug.Log($"已为 {gameObject.name} 设置Collectible标签");
        }
    }

    void Update()
    {
        if (rotate)
        {
            transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime, Space.World);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (showDebugLogs) Debug.Log($"触发收集: {other.name} 收集了 {gameObject.name}");
            Collect();
        }
    }

    public void Collect()
    {
        // 播放音效
        if (collectSound != null)
        {
            AudioSource.PlayClipAtPoint(collectSound, transform.position);
        }

        // 播放粒子效果
        if (collectEffect != null)
        {
            Instantiate(collectEffect, transform.position, Quaternion.identity);
        }

        // 通知CoinManager
        if (CoinManager.Instance != null)
        {
            CoinManager.Instance.CollectCoin(1);
        }
        else
        {
            Debug.LogError("CoinManager实例未找到！");
        }

        // 销毁金币对象
        Destroy(gameObject);
    }

    // 编辑器可视化
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, GetComponent<Collider>().bounds.extents.magnitude * 1.2f);
    }
}